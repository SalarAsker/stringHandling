﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediumVersion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string ursprungligText = "";
        string textToCrypt = "";
        string decryptToText = "";

        private void btnCrypt_Click(object sender, EventArgs e)
        {
            char tecken1, tecken2, tecken3, tecken4, tecken5;

            /************************************************************************************************************* 
            Lösning 1
            
             Plockar ett tecken åt taget. Tecknet förvandlas först till int, adderas två i den, förvandlas tillbaka till char
             och sedan tilldelas.Upprepar samma vid varje tecken i strängen.
             ***************************************************************************************************************/

            if (tbxText.Text != "")//kollar om textboxen inte är tomt
            {
                ursprungligText = tbxText.Text;

                if (ursprungligText.Length == 5)//kollar om längden är 5
                {
                    tecken1 = ursprungligText[0];
                    tecken1 = (char)((int)tecken1 + 2);

                    tecken2 = ursprungligText[1];
                    tecken2 = (char)((int)tecken2 + 2);

                    tecken3 = ursprungligText[2];
                    tecken3 = (char)((int)tecken3 + 2);

                    tecken4 = ursprungligText[3];
                    tecken4 = (char)((int)tecken4 + 2);

                    tecken5 = ursprungligText[4];
                    tecken5 = (char)((int)tecken5 + 2);

                    //bilder krypterad text gneom att lägga ihop alla tecken.
                    textToCrypt = tecken1.ToString() + tecken2.ToString() + tecken3.ToString()
                        + tecken4.ToString() + tecken5.ToString();

                    tbxCryp.Text = textToCrypt;//skickar i textboxen
                }
                else // om ordet inte består av 5 tecken
                {
                    MessageBox.Show("Only word with 5 characters");
                    tbxText.Text = "";
                    tbxText.Focus();
                }

            }
            else //om textboxen är tomt
            {
                MessageBox.Show("Write someting first");
                tbxText.Focus();
            }

            
            /* **************************************************************************
             * Lösning 2
            
            Utan att plocka ett tecken kan man arbeta direkt med strängen och indexering. 
            tilldelande addition operator (+=) bilder strängen testToCrypt
            *****************************************************************************/

            /*
            textToCrypt += (char)((int)ursprungligText[0] + 2);
            textToCrypt += (char)((int)ursprungligText[1] + 2);
            textToCrypt += (char)((int)ursprungligText[2] + 2);
            textToCrypt += (char)((int)ursprungligText[3] + 2);
            textToCrypt += (char)((int)ursprungligText[4] + 2);

            tbxCryp.Text = textToCrypt;//skickar i textboxen

            */

            /* ***************************************************
             * Lösning 3
             
               Kör loop så minskar  man antal rader i lösning nr 2
            *******************************************************/

            /*
            for (int i = 0; i < 5; i++)
            {
                textToCrypt += (char)((int)ursprungligText[i] + 2);
            }

            tbxCryp.Text = textToCrypt;//skickar i textboxen
            */

            btnDecrypt.Enabled = true;


        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            //reverse process
            char tecken1 = textToCrypt[0];
            tecken1 = (char)((int)tecken1 - 2);

            char tecken2 = textToCrypt[1];
            tecken2 = (char)((int)tecken2 - 2);

            char tecken3 = textToCrypt[2];
            tecken3 = (char)((int)tecken3 - 2);

            char tecken4 = textToCrypt[3];
            tecken4 = (char)((int)tecken4 - 2);

            char tecken5 = textToCrypt[4];
            tecken5 = (char)((int)tecken5 - 2);

            decryptToText = tecken1.ToString() + tecken2.ToString() + tecken3.ToString()
                + tecken4.ToString() + tecken5.ToString();

            tbxUrsprunglig.Text = decryptToText;
        }
    }
}
