﻿/*
 Sometimes inputted user string may contains leading or trailing whitespaces. If data is 
 being stored in database it will necessory to remove such whitespaces. Even search function
 will not work properly on string including accidential whitepace. 

 String class provides three method for removing whitespaces.
 
 Trim --> removes leading and trailing whitespaces
 TrimStart --> removes leading whitespaces
 TrimEnd --> removes trailing whitespaces

 ******************************************************************************
 * In this program you will learn how to remove whitespaces before and after string*
 * ****************************************************************************
 
 Author
 Salar Asker Zada
 
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trimming
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string userinput = "  Trimming   ";//string with two leading and three trailing spaces. String length is 12
            lblSummary.Text = "Userinput string length " + userinput.Length.ToString()+
                              "\n\nUserinput string length after applying TrimStart " + userinput.TrimStart().Length.ToString()+
                              "\n\nUserinput string length after applying TrimEnd " + userinput.TrimEnd().Length.ToString()+
                              "\n\nUserinput string length after applying TrimS " + userinput.Trim().Length.ToString();

        }
    }
}
