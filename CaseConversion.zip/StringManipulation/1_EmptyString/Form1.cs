﻿/*
 String manipulation mesans to work with string data.  Strings are an integral part of any programming language.
 You will find string in almost every programming language. String data is being used as input and being
 displayed as output. 
 
 Whenever you visit websites where you often make a login, you simply enter username and password. It's look 
 at the moment very simple but at the backend there is lots of string handling. In programming string handling
 is as important as som others data types. In this sequence of program you will find some way to work quite effiently
 with string.

 ******************************************************************************
 * In this program you will learn how to declare and use empty and null string*
 * ****************************************************************************
 
 Author
 Salar Asker Zada
 
 */



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1_EmptyString
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            //empty string declaraion
            //An empty string means it does not contain any character. The length of empty string is always 0.
            //There must be no space in between citations characters. You can declare an empty string as follows
            string name = "";
            string address = string.Empty;

            //Empty strings are usually used for validating user input. If user entered data or not.
            //See the example.
            if (tbxUserName.Text == "")
            {
                MessageBox.Show("Enter user name");
            }
            if (tbxPassword.Text == string.Empty)
            {
                MessageBox.Show("Enter password");
            }

            // String is a reference type, which means string variable is a reference to string class.
            // A reference variable can hold a null value. A null value means the value is unknown. A typical use of null value is to reset the 
            // string variables. Se exempel.

            // If everyting goes good in the code written above so we will take the input into two different variables, like
            string usernameOk = tbxUserName.Text;
            string passwordOK = tbxPassword.Text;
            // Program will perform further checks here like forward the data to database for verification of username and password.
            // But this beyond the scope of this program. 
            // If username and password is good we can reset usernameOk and passwordOk to make sure that they contain nothing.
            usernameOk = null;
            passwordOK = null;

            // String has a useful method that check if string is empty or null. The method is IsNullOrEmpty. 
            // This method returns a true value if string is empty or null. See example.

            if(string.IsNullOrEmpty(usernameOk) && string.IsNullOrEmpty(passwordOK))
            {
                lblStatus.Text = "Username and password is null";
                tbxUserName.Text = "";
                tbxPassword.Text = "";
            }



        }
    }
}
