﻿/*
 String class provides two methods for case conversion. String class uses users local culture settings
 in order to ensure correct text conversion for various languages.
 
 ToLower --> convert text to lower case
 ToUpper --> convert text to upper case

 ******************************************************************************
 * In this program you will learn how to remove whitespaces before and after string*
 * ****************************************************************************
 
 Author
 Salar Asker Zada
 
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3_CaseConversion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string original = "This is Black And White (åÖä)";
            lblCase.Text = "Original string: " + original +
                "\n\nIn lower case: " + original.ToLower() +
                "\n\nIn upper case: " + original.ToUpper();
        }
    }
}
